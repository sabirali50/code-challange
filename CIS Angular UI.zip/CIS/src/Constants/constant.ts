export const  AUTHOR_NAME = "albert-einstein";
export const  BASE_URL= "https://localhost:7132/"
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BASE_URL,AUTHOR_NAME } from '../../Constants/constant';
@Injectable({
  providedIn: 'root'
})
export class ShipmentDetailsServiceService {
  constructor(private http: HttpClient) { }

  getAllShippers(): Observable<Shipper[]> {
    return this.http.get<Shipper[]>(BASE_URL+'Shipment/All');
  }

  getShipmentDetails(shipperId: number): Observable<ShipmentDetail[]> {
    return this.http.get<ShipmentDetail[]>(BASE_URL+'Shipment/Get/' + shipperId);
  }
}

export interface Shipper {
  shipperId: number;
  shipperName: string;
}

export interface ShipmentDetail {
  shipment_id: number;
  shipper_name: string;
  carrier_name: string;
  shipment_description: string;
  shipment_weight: number;
  shipment_rate_description: string;
}
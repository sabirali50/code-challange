import { TestBed } from '@angular/core/testing';

import { ShipmentDetailsServiceService } from './shipment-details-service.service';

describe('ShipmentDetailsServiceService', () => {
  let service: ShipmentDetailsServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShipmentDetailsServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

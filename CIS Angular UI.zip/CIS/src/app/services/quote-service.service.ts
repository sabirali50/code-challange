import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BASE_URL,AUTHOR_NAME } from '../../Constants/constant';



@Injectable({
  providedIn: 'root'
})

export class QuoteService {
  constructor(private http: HttpClient) { }

  getRandomQuote(): Observable<Quote> {
    return this.http.get<Quote>(BASE_URL+'Quote/RandomQuote');
  }

  getQuotesByAuthor(authorName: string): Observable<QuotesCategory> {
    return this.http.get<QuotesCategory>(BASE_URL+`Quote/Get/${AUTHOR_NAME}`);
  }


}

export interface Quote {
  _id: string;
  author: string;
  content: string;
  tags: string[];
  authorSlug: string;
  length: number;
  dateAdded: string;
  dateModified: string;
}

export interface QuotesCategory{
  Long: Quote[];
  Short: Quote[];
  Medium: Quote[];
}
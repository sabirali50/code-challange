import { Component, OnInit } from '@angular/core';
import { Quote,QuoteService,QuotesCategory } from '../services/quote-service.service';

@Component({
  selector: 'app-quotes',
  templateUrl: './quotes.component.html',
  styleUrls: ['./quotes.component.css']
})
export class QuotesComponent implements OnInit {
  randomQuote!: Quote;
  quotesByAuthor!:QuotesCategory;

  constructor(private quoteService: QuoteService) { }

  ngOnInit() {
    this.quoteService.getRandomQuote().subscribe(data => {
      this.randomQuote = data;
    }, error => {
      console.error('Error: ' + error);
    });

    this.quoteService.getQuotesByAuthor('authorName').subscribe(data => {
      this.quotesByAuthor = data;
    }, error => {
      console.error('Error: ' + error);
    });
  }
}


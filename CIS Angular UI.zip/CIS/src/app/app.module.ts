import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShipmentDetailComponent } from './shipment-detail/shipment-detail.component';
import { QuotesComponent } from './quotes/quotes.component';
import { HttpClientModule } from '@angular/common/http';
import { QuoteService } from './services/quote-service.service';
import { ShipmentDetailsServiceService } from './services/shipment-details-service.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
@NgModule({
  declarations: [
    AppComponent,
    ShipmentDetailComponent,
    QuotesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [QuoteService,ShipmentDetailsServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }

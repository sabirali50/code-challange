import { Component, OnInit } from '@angular/core';
import { ShipmentDetailsServiceService,Shipper, ShipmentDetail} from '../services/shipment-details-service.service';

@Component({
  selector: 'app-shipment-detail',
  templateUrl: './shipment-detail.component.html',
  styleUrls: ['./shipment-detail.component.css']
})
export class ShipmentDetailComponent implements OnInit {
  shippers: Shipper[] = [];
  shipmentDetails: ShipmentDetail[] = [];

  constructor(private shipmentService: ShipmentDetailsServiceService) { }

  ngOnInit(): void {
    this.shipmentService.getAllShippers().subscribe(shippers => {
      this.shippers = shippers.sort((a, b) => a.shipperName.localeCompare(b.shipperName));

    });
  }

  getShipmentDetails(shipperId: number) {
    this.shipmentService.getShipmentDetails(shipperId).subscribe(details => {
      this.shipmentDetails = details;
    });
  }
}